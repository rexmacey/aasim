#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom graphics layout
#' @importFrom reshape2 melt
#' @importFrom stats filter
#' @importFrom stats median
#' @importFrom stats pnorm
#' @importFrom stats quantile
#' @importFrom stats uniroot
## usethis namespace: end
NULL
