simTest <- simulatefromexcel(paste0(testthat::test_path(),"/data/siminput.xlsx"))
